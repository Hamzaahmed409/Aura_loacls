import React from 'react'

export default function DashBoard() {
  return (
    <div className=' bg-slate-50 w-full h-screen'>
      <h1  className=' text-cyan-600 text-center text-2xl pt-20'>
        DashBoard
      </h1>
    </div>
  )
}
