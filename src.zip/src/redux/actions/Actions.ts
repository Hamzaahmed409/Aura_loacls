export const SET_AUTH_USER = 'SET_AUTH_USER';
export const LOGOUT = 'LOGOUT';


export const SET_SHOW_MODAL = 'SET_SHOW_MODAL';
export const SET_HIDE_MODAL = 'SET_HIDE_MODAL';