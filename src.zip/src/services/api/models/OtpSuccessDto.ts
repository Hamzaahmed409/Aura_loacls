/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type OtpSuccessDto = {
    message: string;
    user_id: string;
    seller_id: string;
};

