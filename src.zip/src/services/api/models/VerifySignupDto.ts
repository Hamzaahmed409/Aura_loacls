/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type VerifySignupDto = {
    country_code: string;
    mobile_number: string;
    otp: string;
    name: string;
    email: string;
};

