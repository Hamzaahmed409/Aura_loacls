/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type SignupDto = {
    user_id: string;
    seller_id: string;
    company_name?: string;
    company_registered_name?: string;
    avg_num_invoices?: string;
    date_of_incorporation?: string;
    annual_turnover?: string;
    business_category?: string;
};

