/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { FailedUploadResultObject } from './FailedUploadResultObject';
import type { SuccessUploadResultObject } from './SuccessUploadResultObject';
export type UploadResultDto = {
    successfulUploads: Array<SuccessUploadResultObject>;
    failedUploads: Array<FailedUploadResultObject>;
};

