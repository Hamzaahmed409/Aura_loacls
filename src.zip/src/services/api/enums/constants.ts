export enum DOCUMENTTYPE{
    BANKSTATEMENT = "bank_statement",
    TRADELICENSE = "trade_license"
}